export const enum eSettingRouteNames {
  Setting = 'Setting::Menu:Setting'
}
