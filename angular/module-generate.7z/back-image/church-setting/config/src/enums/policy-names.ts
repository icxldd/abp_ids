export const enum eSettingPolicyNames {
  Book = 'Ids.MyPermission1',
  // Audits
}
