/*
 * Public API Surface of setting
 */

export * from './lib/services/setting.service';
export * from './lib/setting.module';
